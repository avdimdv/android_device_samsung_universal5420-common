F=system/vendor/lib/libbt-vendor.so
CTX=$(ls -Z /vendor/lib/libbt-vendor.so 2>/dev/null | awk '{print $1}')
[ -n "$CTX" ] || CTX=u:object_r:vendor_file:s0
ui_print "- label: $CTX"
set_perm $MODPATH/$F 0 0 0644 $CTX
