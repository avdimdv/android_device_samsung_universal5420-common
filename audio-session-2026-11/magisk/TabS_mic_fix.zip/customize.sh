F=system/vendor/etc/mixer_paths_0.xml
CTX=$(ls -Z /vendor/etc/mixer_paths_0.xml 2>/dev/null | awk '{print $1}')
[ -n "$CTX" ] || CTX=u:object_r:vendor_configs_file:s0
ui_print "- label: $CTX"
set_perm $MODPATH/$F 0 0 0644 $CTX
